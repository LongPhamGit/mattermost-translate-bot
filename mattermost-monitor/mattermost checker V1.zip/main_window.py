# main_window.py
import os, html as html_lib
from datetime import datetime
from markdown import markdown

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QPushButton, QLabel,
    QMessageBox, QSizePolicy
)
from PyQt6.QtGui import QFont
from PyQt6.QtWebEngineWidgets import QWebEngineView

from config_loader import HTML_LOG_FILE, MY_USERNAME
from signals_bus import signals
from html_log import HTML_HEADER, HTML_FOOTER, append_html
from webview_pages import ExternalLinkPage


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Mattermost Checker")

        # ===================== BANNER (low height & navy) =====================
        banner = QLabel("Mattermost Checker")
        banner_font = QFont("Segoe UI", 13, QFont.Weight.Bold)
        banner.setFont(banner_font)
        banner.setAlignment(Qt.AlignmentFlag.AlignCenter)
        banner.setFixedHeight(36)
        banner.setStyleSheet("""
            QLabel {
                color: #ffffff;
                background-color: #2F3C56;
                padding: 6px 10px;
                border-radius: 4px;
                letter-spacing: 0.3px;
            }
        """)

        # ===================== TOP BAR =====================
        font_btn = QFont("Arial", 12)
        font_label = QFont("Arial", 12)

        # CHANGED: English label
        self.btn_open = QPushButton("Open HTML log file")
        self.btn_open.setFont(font_btn)
        self.btn_open.setStyleSheet("padding:5px 12px;")

        self.lbl_status = QLabel("Not connected")
        self.lbl_status.setFont(font_label)
        self.lbl_status.setStyleSheet("color:#b00020;")  # text color only

        # CHANGED: English label
        self.lbl_count = QLabel("Total messages: 0")
        self.lbl_count.setFont(font_label)

        self.btn_clear = QPushButton("Clear")
        self.btn_clear.setFont(font_btn)
        self.btn_clear.setStyleSheet("padding:5px 12px;")

        # Layout: left (Open), center (Status), right (Count + Clear)
        left_layout = QHBoxLayout()
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(4)
        left_layout.addWidget(self.btn_open)

        center_layout = QHBoxLayout()
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(4)
        center_layout.addWidget(self.lbl_status)

        right_layout = QHBoxLayout()
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)
        right_layout.addWidget(self.lbl_count)
        right_layout.addWidget(self.btn_clear)

        top_layout = QHBoxLayout()
        top_layout.setContentsMargins(2, 0, 2, 0)
        top_layout.setSpacing(4)
        top_layout.addLayout(left_layout)
        top_layout.addStretch(1)
        top_layout.addLayout(center_layout)
        top_layout.addStretch(1)
        top_layout.addLayout(right_layout)

        top_widget = QWidget()
        top_widget.setLayout(top_layout)
        top_widget.setFixedHeight(40)
        top_widget.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)

        # ===================== WEB VIEW =====================
        self.web = QWebEngineView()
        self.web.setPage(ExternalLinkPage(self.web))

        # Empty GUI at startup
        self.gui_body = ""
        self.set_web_html()

        # ===================== MAIN LAYOUT =====================
        v = QVBoxLayout()
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(8)
        v.addWidget(banner)
        v.addWidget(top_widget)
        v.addWidget(self.web)
        self.setLayout(v)
        self.resize(1000, 760)

        # ===================== SIGNALS =====================
        self.btn_open.clicked.connect(self.open_log)
        self.btn_clear.clicked.connect(self.clear_display_and_reset_count)
        signals.new_message.connect(self.on_new_message)
        signals.set_connected.connect(self.on_set_connected)
        signals.update_count.connect(self.on_update_count)
        signals.clicked.connect(self._show_and_scroll_bottom, type=Qt.ConnectionType.QueuedConnection)

    # === Bring-to-front & scroll to bottom ===
    def _show_and_scroll_bottom(self):
        try:
            self.setWindowState(self.windowState() & ~Qt.WindowMinimized)
            self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
            self.show()
            self.raise_()
            self.activateWindow()
            QTimer.singleShot(600, self._clear_on_top_flag)

            js = r"""
            (function(){
                var cont = document.querySelector('.container');
                if (cont) {
                    try { cont.scrollTop = cont.scrollHeight; } catch(e){}
                    try { if (cont.lastElementChild) cont.lastElementChild.scrollIntoView({behavior:'instant', block:'end'}); } catch(e){}
                } else {
                    try { window.scrollTo(0, document.body.scrollHeight); } catch(e){}
                }
                return true;
            })();
            """
            self.web.page().runJavaScript(js)
        except Exception:
            pass

    def _clear_on_top_flag(self):
        try:
            self.setWindowFlag(Qt.WindowStaysOnTopHint, False)
            self.show()
        except Exception:
            pass

    def set_web_html(self):
        self.web.setHtml(HTML_HEADER + self.gui_body + HTML_FOOTER)

    def open_log(self):
        path = os.path.abspath(HTML_LOG_FILE)
        try:
            if os.path.exists(path):
                if os.name == "nt":
                    os.startfile(path)
                else:
                    import webbrowser
                    webbrowser.open(f"file://{path}")
            else:
                # giữ nguyên messagebox tiếng Việt như yêu cầu trước
                QMessageBox.warning(self, "Lỗi", f"Không tìm thấy file: {path}")
        except Exception:
            QMessageBox.warning(self, "Lỗi", f"Không mở được file: {path}")

    def clear_display_and_reset_count(self):
        self.gui_body = ""
        self.set_web_html()
        signals.reset_count.emit()  # ask WSClient to reset counter

    def on_new_message(self, sender, channel, message, translated):
        is_personal = (f"@{MY_USERNAME.lower()}" in (message or "").lower())
        css_class = "mention" if is_personal else "normal"
        safe_text = html_lib.escape(message or "")
        safe_trans = html_lib.escape(translated or "")
        html_text = markdown(safe_text, extensions=["fenced_code", "tables"])
        html_trans = markdown(safe_trans, extensions=["fenced_code", "tables"]) if safe_trans else ""

        entry = (
            f"<div class='msg {'mention' if css_class=='mention' else ''}'>"
            f"<div class='timestamp'>[{html_lib.escape(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}]</div>"
            f"<div><span class='sender'>{html_lib.escape(sender)}</span> "
            f"in <span class='channel'>{html_lib.escape(channel)}</span></div>"
            f"<div class='content'>{html_text}</div>"
        )
        if html_trans:
            entry += f"<div class='translated'>{html_trans}</div>"
        entry += "</div>\n"

        self.gui_body += entry
        self.set_web_html()
        append_html(sender, channel, message, css_class=("mention" if css_class=="mention" else "normal"), translated=translated)

    def on_set_connected(self, ok: bool):
        if ok:
            self.lbl_status.setText("Connected")
            self.lbl_status.setStyleSheet("color:#2563eb;")  # blue when Connected
        else:
            self.lbl_status.setText("Not connected")
            self.lbl_status.setStyleSheet("color:#b00020;")  # red when Not connected

    def on_update_count(self, count: int):
        self.lbl_count.setText(f"Total messages: {count}")
