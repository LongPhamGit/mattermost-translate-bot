# app.py (hoặc main.py)
import sys
from PyQt6.QtWidgets import QApplication
from main_window import MainWindow
from ws_client import WSClient
from notifications import init_qt_tray

def main():
    app = QApplication(sys.argv)
    init_qt_tray(app)  # << quan trọng

    win = MainWindow()
    wsclient = WSClient()
    wsclient.start()

    win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
