# notifications.py
from signals_bus import signals

# Qt tray (clickable) + fallback plyer (no click)
_tray = None

def _make_default_icon():
    """Vẽ icon tròn navy nhỏ để khay hệ thống có icon hợp lệ."""
    try:
        from PyQt6.QtGui import QIcon, QPixmap, QPainter, QColor, QPen
        from PyQt6.QtCore import Qt
    except Exception:
        return None

    pm = QPixmap(32, 32)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    pen = QPen(QColor("#2F3C56"))
    pen.setWidth(2)
    p.setPen(pen)
    p.setBrush(QColor("#2F3C56"))
    p.drawEllipse(4, 4, 24, 24)
    p.end()
    return QIcon(pm)

def init_qt_tray(app, icon_path: str | None = None):
    """
    Tạo QSystemTrayIcon một lần trong main thread.
    - Click vào balloon (messageClicked) -> signals.clicked.emit()
    - Click vào icon khay (single/double) -> signals.clicked.emit()
    """
    global _tray
    if _tray is not None:
        return

    try:
        from PyQt6.QtWidgets import QSystemTrayIcon
        from PyQt6.QtGui import QIcon
        from PyQt6.QtCore import QObject
    except Exception:
        return

    icon = None
    if icon_path:
        try:
            icon = QIcon(icon_path)
        except Exception:
            icon = None
    if icon is None:
        icon = _make_default_icon()

    _tray = QSystemTrayIcon(icon, app)
    _tray.setToolTip("Mattermost Checker")

    # Click vào balloon
    _tray.messageClicked.connect(lambda: signals.clicked.emit())

    # Click vào icon khay (một số máy không bắn messageClicked ổn định)
    def _on_activated(reason):
        # Trigger = single click, DoubleClick = double click
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick
        ):
            signals.clicked.emit()
    _tray.activated.connect(_on_activated)

    _tray.show()

def _ensure_tray():
    """Nếu chưa init tray, thử tạo bằng QApplication.instance()."""
    global _tray
    if _tray is not None:
        return True
    try:
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            return False
        init_qt_tray(app)
        return _tray is not None
    except Exception:
        return False

def send_clickable_toast(title: str, message: str):
    """
    Gửi thông báo:
    1) Dùng QSystemTrayIcon.showMessage (clickable).
    2) Nếu không có Qt tray (rất hiếm), fallback sang plyer (không click).
    """
    # 1) Qt tray (clickable)
    try:
        from PyQt6.QtWidgets import QSystemTrayIcon
    except Exception:
        QSystemTrayIcon = None

    if QSystemTrayIcon is not None and _ensure_tray() and _tray.supportsMessages():
        _tray.showMessage(title, message, QSystemTrayIcon.MessageIcon.Information, 8000)
        return

    # 2) Fallback: plyer (không có click)
    try:
        from plyer import notification as plyer_notification
        plyer_notification.notify(title=title, message=message, timeout=5)
    except Exception:
        pass
