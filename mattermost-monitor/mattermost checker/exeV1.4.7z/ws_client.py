# ws_client.py
import json
import threading
import time
import websocket
from collections import deque

from PyQt6.QtCore import Qt

from config_loader import (
    WS_URL, MY_USERNAME, WATCH_CHANNELS, USER_MAP, CHANNEL_MAP,
    MMUSERID, MMAUTHTOKEN, API_KEY, GEMINI_URL
)
from signals_bus import signals
from notifications import send_clickable_toast
from translate import translate_with_fallback


class WSClient:
    def __init__(self):
        self.ws = None
        self.msg_count = 0

        # target language for translation (default 'vi')
        self.target_lang = "vi"

        # guard to prevent multiple start threads
        self._started = False

        # remember seen messages to avoid duplicates on reconnect / multi-clients
        self._seen_ids = set()
        self._seen_ids_order = deque(maxlen=1000)  # keep recent 1000 ids

        # fallback dedupe when post.id is missing
        self._seen_hash = set()
        self._seen_hash_order = deque(maxlen=1000)

        # ---- lifecycle / gating ----
        self._app_started_ms = int(time.time() * 1000)   # ms epoch when process started

        # Gate 1: chỉ nhận post có create_at >= _accept_from_ms (đặt mỗi lần on_open)
        self._accept_from_ms = None

        # Gate 2: drop cứng theo thời gian thực trong vài giây đầu kể từ on_open
        self._accept_from_mono = 0.0
        self._DROP_WINDOW_SEC = 3.0

        self._last_focus_ms = 0                          # ms khi user click (bring-to-front)
        self._connected_monotonic = 0.0                  # time.monotonic() khi on_open
        self._FOCUS_BUFFER_MS = 2000
        self._RECONNECT_WARMUP_SEC = 2.0

        # Signals
        signals.reset_count.connect(self._on_reset_count, type=Qt.ConnectionType.UniqueConnection)
        signals.translate_lang_changed.connect(self._on_lang_changed, type=Qt.ConnectionType.UniqueConnection)
        signals.clicked.connect(self._on_user_focus, type=Qt.ConnectionType.UniqueConnection)

    # ===== slots from signals_bus =====
    def _on_reset_count(self):
        self.msg_count = 0
        signals.update_count.emit(0)

    def _on_lang_changed(self, code: str):
        self.target_lang = code if code in ("vi", "en", "ja", "id") else "vi"

    def _on_user_focus(self):
        self._last_focus_ms = int(time.time() * 1000)

    # ===== lifecycle =====
    def start(self):
        """Run client in a dedicated thread and auto-reconnect every 1s on drop."""
        if self._started:
            return  # prevent double-start
        self._started = True

        t = threading.Thread(target=self._run_loop, daemon=True)
        t.start()

    def _run_loop(self):
        while True:
            try:
                self.ws = websocket.WebSocketApp(
                    WS_URL,
                    header=[self._cookie_header()],
                    on_message=self.on_message,
                    on_error=self.on_error,
                    on_close=self.on_close,
                    on_open=self.on_open
                )
                self.ws.run_forever()
            except Exception:
                # swallow and retry
                pass
            signals.set_connected.emit(False)
            time.sleep(1)

    def _cookie_header(self):
        return f"Cookie: MMUSERID={MMUSERID}; MMAUTHTOKEN={MMAUTHTOKEN}"

    # ===== WebSocket callbacks =====
    def on_open(self, ws):
        try:
            auth = {"seq": 1, "action": "authentication_challenge", "data": {"token": MMAUTHTOKEN}}
            ws.send(json.dumps(auth))
        except Exception:
            pass

        # Đặt mốc "chỉ nhận tin mới từ lúc này" mỗi lần kết nối thành công
        # + thêm 1500ms để bù lệch giờ/event đến sớm
        now_ms = int(time.time() * 1000)
        self._accept_from_ms = now_ms + 1500

        # Cửa sổ DROP cứng theo thời gian thực (không phụ thuộc timestamp server)
        self._accept_from_mono = time.monotonic()

        self._connected_monotonic = time.monotonic()
        signals.set_connected.emit(True)

    def on_message(self, ws, message):
        # parse envelope
        try:
            data = json.loads(message)
        except Exception:
            return
        if data.get("event") != "posted":
            return

        # parse post
        try:
            post = json.loads(data["data"]["post"])
        except Exception:
            return

        channel_id = post.get("channel_id")
        if channel_id not in WATCH_CHANNELS:
            return

        # ===== GATE 2: DROP theo thời gian thực trong vài giây đầu kể từ on_open =====
        if (time.monotonic() - self._accept_from_mono) < self._DROP_WINDOW_SEC:
            return

        # ===== GATE 1: BỎ TIN NHẮN CŨ so với mốc accept_from_ms =====
        gate_ms = self._accept_from_ms or self._app_started_ms
        try:
            post_ms = int(post.get("create_at") or 0)
        except Exception:
            post_ms = 0
        if post_ms <= 0:
            # nếu thiếu timestamp, coi là cũ (để an toàn) => bỏ qua
            return
        if post_ms < gate_ms:
            return

        # ---- DEDUPE BEGIN ----
        post_id = post.get("id")
        if post_id:
            if post_id in self._seen_ids:
                return
            self._seen_ids.add(post_id)
            self._seen_ids_order.append(post_id)
            if len(self._seen_ids_order) > self._seen_ids_order.maxlen:
                old = self._seen_ids_order.popleft()
                self._seen_ids.discard(old)
        else:
            key = (post.get("user_id", ""), post.get("channel_id", ""), post.get("message", ""))
            if key in self._seen_hash:
                return
            self._seen_hash.add(key)
            self._seen_hash_order.append(key)
            if len(self._seen_hash_order) > self._seen_hash_order.maxlen:
                oldk = self._seen_hash_order.popleft()
                self._seen_hash.discard(oldk)
        # ---- DEDUPE END ----

        user_id = post.get("user_id", "unknown")
        sender = USER_MAP.get(user_id, user_id)
        channel_name = CHANNEL_MAP.get(channel_id, channel_id)
        raw_text = (post.get("message", "") or "").strip()

        lower = raw_text.lower()
        is_personal = f"@{MY_USERNAME.lower()}" in lower
        is_channel = any(k in lower for k in ("@channel", "@here", "@all"))

        # ===== Translate with fallback (Gemini -> googletrans -> LibreTranslate) =====
        translated = ""
        try:
            translated = translate_with_fallback(raw_text, self.target_lang)
        except Exception:
            translated = ""

        # emit to GUI (luôn hiển thị trong UI)
        signals.new_message.emit(sender, channel_name, raw_text, translated)

        # update counter
        self.msg_count += 1
        signals.update_count.emit(self.msg_count)

        # ===== Focus-aware notification filter =====
        baseline_ms = max(self._app_started_ms, self._last_focus_ms)
        is_old_vs_focus = post_ms < (baseline_ms - self._FOCUS_BUFFER_MS)
        just_connected = (time.monotonic() - self._connected_monotonic) < self._RECONNECT_WARMUP_SEC

        should_notify = False
        if not is_old_vs_focus:
            if is_personal:
                should_notify = True
                title = f"Mention từ {sender} trong #{channel_name}"
            elif is_channel:
                should_notify = True
                title = f"Channel mention trong #{channel_name}"

        if just_connected and is_old_vs_focus:
            should_notify = False

        if should_notify:
            self.notify(title, raw_text)

    def on_error(self, ws, error):
        signals.set_connected.emit(False)

    def on_close(self, ws, close_status_code, close_msg):
        signals.set_connected.emit(False)

    # ===== notifications =====
    def notify(self, title, message):
        send_clickable_toast(title, message)
