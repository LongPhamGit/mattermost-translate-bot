# translate.py
import os
import requests
from config_loader import API_KEY, GEMINI_URL

# ======= Fallback config (có thể override bằng ENV) =======
FREE_TRANSLATE_URL = os.environ.get("FREE_TRANSLATE_URL", "https://libretranslate.de/translate")
FREE_TRANSLATE_API_KEY = os.environ.get("FREE_TRANSLATE_API_KEY", None)
FREE_TRANSLATE_TIMEOUT = float(os.environ.get("FREE_TRANSLATE_TIMEOUT", "12"))

# Thử import googletrans (không bắt buộc)
_HAVE_GOOGLETRANS = False
try:
    from googletrans import Translator as _GT_Translator  # pip install googletrans==4.0.0rc1
    _GT = _GT_Translator()
    _HAVE_GOOGLETRANS = True
except Exception:
    _HAVE_GOOGLETRANS = False

# Chuẩn hoá mã ngôn ngữ
_LANG_MAP = {
    "vi": "vi",
    "en": "en",
    "ja": "ja",
    "id": "id",
}
_LANG_NAME = {
    "vi": "Vietnamese",
    "en": "English",
    "ja": "Japanese",
    "id": "Indonesian",
}
def _norm_lang(code: str) -> str:
    return _LANG_MAP.get((code or "vi").lower(), "vi")


# ========== Primary: Gemini ==========
def call_gemini_translate(text: str, target_language: str = "vi") -> str:
    """
    Dịch bằng Gemini. Nếu thành công → trả về có prefix '🔁 '.
    Nếu lỗi → trả về '[Lỗi dịch]' (nội bộ), translate_with_fallback sẽ KHÔNG hiển thị chuỗi này.
    """
    if not API_KEY or not GEMINI_URL:
        return "[Lỗi dịch]"
    tgt_name = _LANG_NAME.get(_norm_lang(target_language), "Vietnamese")
    #prompt_text = f"Translate to {tgt_name}, no explanation, keep the meaning: {text}"
    prompt_text = f"""Translate the following text into {tgt_name}.
                    Rules (strict):
                    - Output ONLY ONE single best translation.
                    - Do NOT provide multiple options.
                    - Do NOT explain.
                    - Do NOT add notes.
                    - Do NOT add context.
                    - Answer must be exactly one plain sentence, no more.
                    Text: {text}"""




    headers = {"Content-Type": "application/json", "X-goog-api-key": API_KEY}
    payload = {
        "contents": [
            {"role": "user", "parts": [{"text": prompt_text}]}
        ]
    }
    try:
        resp = requests.post(GEMINI_URL, headers=headers, json=payload, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        out = data["candidates"][0]["content"]["parts"][0]["text"].strip()
        return "🔁 " + out
    except Exception:
        return "[Lỗi dịch]"


# ========== Secondary: googletrans ==========
def _call_googletrans(text: str, target_language: str) -> str:
    if not _HAVE_GOOGLETRANS:
        raise RuntimeError("googletrans not installed")
    dest = _norm_lang(target_language)
    result = _GT.translate(text, dest=dest)
    out = (result.text or "").strip()
    if not out:
        raise RuntimeError("googletrans returned empty")
    return out


# ========== Tertiary: LibreTranslate ==========
def _call_libretranslate(text: str, target_language: str) -> str:
    if not FREE_TRANSLATE_URL:
        raise RuntimeError("FREE_TRANSLATE_URL is not set")
    tgt = _norm_lang(target_language)
    payload = {
        "q": text,
        "source": "auto",
        "target": tgt,
        "format": "text",
    }
    if FREE_TRANSLATE_API_KEY:
        payload["api_key"] = FREE_TRANSLATE_API_KEY

    r = requests.post(FREE_TRANSLATE_URL, json=payload, timeout=FREE_TRANSLATE_TIMEOUT)
    r.raise_for_status()
    data = r.json()
    out = (data.get("translatedText") or data.get("translation") or "").strip()
    if not out:
        raise RuntimeError("LibreTranslate returned empty")
    return out


# ========== Public API: dịch với fallback ==========
def translate_with_fallback(text: str, target_language: str = "vi") -> str:
    """
    Chuỗi fallback:
        1) Gemini (prefix 🔁)
        2) googletrans (prefix 🌐)
        3) LibreTranslate (prefix 🆓)
    KHÔNG bao giờ trả về chuỗi "[Lỗi dịch]" ra ngoài; nếu tất cả đều lỗi -> trả rỗng.
    """
    text = text or ""
    if not text.strip():
        return ""

    # 1) Gemini
    try:
        g = call_gemini_translate(text, target_language=target_language)
        if g and not g.strip().lower().startswith(("[lỗi dịch]", "[loi dich]")):
            return g  # giữ nguyên prefix 🔁
    except Exception:
        pass

    # 2) googletrans
    try:
        gt = _call_googletrans(text, target_language)
        if gt:
            return "🌐 " + gt
    except Exception:
        pass

    # 3) LibreTranslate
    try:
        lt = _call_libretranslate(text, target_language)
        if lt:
            return "🆓 " + lt
    except Exception:
        pass

    # 4) Hết cách: trả rỗng -> UI sẽ không hiển thị dòng lỗi
    return ""
