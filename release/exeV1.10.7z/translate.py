# translate.py
import re
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import os

from config_loader import API_KEY, GEMINI_URL

# ===== Prefix hiển thị (có thể override bằng ENV) =====
# Lưu ý: GG_PREFIX mặc định vẫn bắt đầu bằng "🔁 " để hợp UI cũ (nếu UI check startswith("🔁 "))
GEMINI_PREFIX = os.getenv("GEMINI_PREFIX", "🔁 ")
GG_PREFIX     = os.getenv("GG_PREFIX",     "🔁 [By googleTrans] ")
FAIL_MSG      = os.getenv("FAIL_MSG",      "🔁 Không thể dịch ngay lúc này. Vui lòng thử lại sau.")

# ===== Ngôn ngữ =====
_LANG_MAP = {"vi": "vi", "en": "en", "ja": "ja", "id": "id"}
_LANG_NAME = {"vi": "Vietnamese", "en": "English", "ja": "Japanese", "id": "Indonesian"}
def _norm_lang(code: str) -> str:
    return _LANG_MAP.get((code or "vi").lower(), "vi")

# ===== Helpers =====
def _build_translate_prompt(tgt_name: str, text: str) -> str:
    return (
        f"Translate to {tgt_name}, no explanation, keep the meaning: {text}"
        '''
        f"Translate ALL natural language parts into {tgt_name}. "
        "Do NOT skip or leave text untranslated. "
        "Do not explain. Preserve all original Markdown formatting. "
        "Keep line breaks exactly the same (1 input line -> 1 output line). "
        f"Translate even if the input already contains some {tgt_name} words.\n\n"
        "INPUT (markdown):\n```markdown\n"
        f"{text}\n"
        "```\n\nOUTPUT (markdown only):"
        '''
    )

def _strip_fences(s: str) -> str:
    s = (s or "").strip()
    if s.startswith("```") and s.endswith("```"):
        lines = s.splitlines()
        if len(lines) >= 2:
            return "\n".join(lines[1:-1]).strip()
    return s

def _repair_markdown_structure(src: str, out: str) -> str:
    if not isinstance(out, str):
        return out
    src_lines = [ln.rstrip() for ln in (src or "").splitlines()]

    def _is_bullet(ln: str) -> bool:
        ln = ln.lstrip()
        return ln.startswith(("-", "*", "+")) or re.match(r"^\d+\.\s", ln) is not None

    had_bullets = sum(1 for ln in src_lines if _is_bullet(ln)) >= 2
    if had_bullets and ("\n" not in out):
        for a, b in [(" - ", "\n- "), (" • ", "\n- "), (" ・", "\n- "),
                     (" + ", "\n+ "), (" * ", "\n* ")]:
            if a in out:
                out = out.replace(a, b)
        out = re.sub(r"\s(\d+\.\s)", r"\n\1", out)
    return out

def _make_retry_session(total: int = 2, backoff_factor: float = 0.6) -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=total, connect=total, read=total, status=total,
        backoff_factor=backoff_factor,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["POST"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    return s

# ===== Provider: Gemini =====
def _gemini_call(text: str, target_language: str) -> str:
    """Trả text đã dịch (không kèm prefix). Lỗi -> raise để caller fallback."""
    if not API_KEY or not GEMINI_URL:
        raise RuntimeError("Gemini config missing")

    tgt_code = _norm_lang(target_language)
    tgt_name = _LANG_NAME.get(tgt_code, "Vietnamese")
    headers = {"Content-Type": "application/json", "X-goog-api-key": API_KEY}
    payload_base = {"contents": [{"role": "user", "parts": [{"text": _build_translate_prompt(tgt_name, text)}]}]}
    payload_1 = {**payload_base, "generationConfig": {
        "temperature": 0.2, "topK": 1, "topP": 0.9, "response_mime_type": "text/markdown"
    }}

    session = _make_retry_session()

    # try #1
    resp = session.post(GEMINI_URL, headers=headers, json=payload_1, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    try:
        out = data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception:
        # try #2 (no generationConfig)
        resp2 = session.post(GEMINI_URL, headers=headers, json=payload_base, timeout=15)
        resp2.raise_for_status()
        data2 = resp2.json()
        out = data2["candidates"][0]["content"]["parts"][0]["text"].strip()

    out = _strip_fences(out)
    return _repair_markdown_structure(text, out)

# ===== Provider: googletrans =====
def _googletrans_call(text: str, target_language: str) -> str:
    """Trả text đã dịch (không kèm prefix). Lỗi -> raise."""
    try:
        from googletrans import Translator  # lazy import để tránh lỗi import-time
    except Exception as e:
        raise RuntimeError("googletrans not installed") from e

    dest = _norm_lang(target_language)
    t = Translator()
    res = t.translate(text, dest=dest)
    out = (getattr(res, "text", "") or "").strip()
    if not out:
        raise RuntimeError("googletrans returned empty")
    return _repair_markdown_structure(text, out)

# ===== Public APIs =====
def call_gemini_translate(text: str, target_language: str = "vi") -> str:
    """
    [Giữ tương thích với ws_client]
    - Thử Gemini; nếu lỗi → fallback googletrans.
    - Gemini OK  -> prefix GEMINI_PREFIX
    - Googletrans-> prefix GG_PREFIX (mặc định: '🔁 [By googleTrans] ')
    - Tất cả lỗi -> FAIL_MSG (cũng bắt đầu bằng '🔁 ' để UI cũ hiển thị).
    """
    text = (text or "")
    if not text.strip():
        return ""

    # 1) Gemini
    try:
        out = _gemini_call(text, target_language)
        if out:
            return GEMINI_PREFIX + out
    except Exception:
        pass  # fallback

    # 2) googletrans
    try:
        out = _googletrans_call(text, target_language)
        if out:
            return GG_PREFIX + out
    except Exception:
        pass

    # 3) Tổng thất bại → vẫn trả message có prefix '🔁 '
    return FAIL_MSG

def translate_with_fallback(text: str, target_language: str = "vi") -> str:
    """API mới: cùng logic với call_gemini_translate."""
    return call_gemini_translate(text, target_language)
