import os, sys, platform
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon
from main_window import MainWindow
from ws_client import WSClient
from notifications import init_qt_tray
from signals_bus import signals

# --- AppUserModelID (Windows) để taskbar nhận đúng icon ---
if sys.platform == "win32":
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            u"LP.MattermostChecker"   # ID bạn muốn
        )
    except Exception:
        pass

def resource_path(relative_path: str) -> str:
    """Trả về path khi chạy bằng source hoặc exe PyInstaller"""
    if hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(__file__)
    return os.path.join(base_path, relative_path)

def flash_taskbar(win):
    if platform.system() == "Windows":
        try:
            import ctypes, ctypes.wintypes
            hwnd = int(win.winId())

            class FLASHWINFO(ctypes.Structure):
                _fields_ = [
                    ('cbSize', ctypes.wintypes.UINT),
                    ('hwnd', ctypes.wintypes.HWND),
                    ('dwFlags', ctypes.wintypes.DWORD),
                    ('uCount', ctypes.wintypes.UINT),
                    ('dwTimeout', ctypes.wintypes.DWORD),
                ]

            FLASHW_ALL = 3
            FLASHW_TIMERNOFG = 12  # nháy khi chưa focus

            flash_info = FLASHWINFO(
                ctypes.sizeof(FLASHWINFO),
                hwnd,
                FLASHW_ALL | FLASHW_TIMERNOFG,
                0,
                0
            )
            ctypes.windll.user32.FlashWindowEx(ctypes.byref(flash_info))
        except Exception as e:
            print("Lỗi FlashWindowEx:", e)

def main():
    app = QApplication(sys.argv)

    # --- Icon cho app (hiện ở taskbar) ---
    app_icon = QIcon(resource_path("icon.ico"))
    app.setWindowIcon(app_icon)

    # Nếu app có lúc ẩn hết cửa sổ thì vẫn chạy với tray
    app.setQuitOnLastWindowClosed(False)

    # --- System tray icon ---
    # notifications.py nên load "icon.png" (dùng resource_path) để hiển thị
    init_qt_tray(app)

    # --- Main window ---
    win = MainWindow()
    win.setWindowIcon(app_icon)

    def show_main_window():
        if win.isMinimized():
            win.showNormal()
        else:
            win.show()
        win.raise_()
        win.activateWindow()

    signals.clicked.connect(show_main_window)
    signals.new_message.connect(lambda _: flash_taskbar(win))

    wsclient = WSClient()
    wsclient.start()

    win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
